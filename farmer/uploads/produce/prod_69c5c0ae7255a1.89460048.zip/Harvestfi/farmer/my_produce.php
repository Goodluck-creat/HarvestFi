<?php
include "db.php";

$farmer_id = 1; // Replace with session ID

// --- 1. HANDLE DELETE ---
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM produce WHERE id = $id AND farmer_id = $farmer_id");
    header("Location: my_produce.php?msg=deleted");
    exit();
}

// --- 2. HANDLE MULTI-IMAGE UPLOAD ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_produce'])) {
    $name = $_POST['name'];
    $desc = $_POST['description'];
    $price = $_POST['price'];
    $qty = $_POST['quantity'];
    
    $uploaded_images = [];
    $target_dir = "uploads/produce/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);

    // Loop through multiple files
    foreach ($_FILES['images']['name'] as $key => $val) {
        if (!empty($_FILES['images']['name'][$key])) {
            $file_name = time() . "_" . $key . "_" . basename($_FILES["images"]["name"][$key]);
            $target_path = $target_dir . $file_name;
            
            if (move_uploaded_file($_FILES["images"]["tmp_name"][$key], $target_path)) {
                $uploaded_images[] = $target_path;
            }
        }
    }

    // Convert array to JSON string for database
    $image_json = json_encode($uploaded_images);

    $stmt = $conn->prepare("INSERT INTO produce (farmer_id, name, description, quantity, price, image, status) VALUES (?, ?, ?, ?, ?, ?, 'available')");
    $stmt->bind_param("isssds", $farmer_id, $name, $desc, $qty, $price, $image_json);
    $stmt->execute();
    
    header("Location: my_produce.php?msg=success");
    exit();
}

$result = $conn->query("SELECT * FROM produce WHERE farmer_id = $farmer_id ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Produce | HarvestFi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --harvest-green: #2d9447; }
        body { background: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
        .sidebar { height: 100vh; width: 250px; position: fixed; background: var(--harvest-green); color: white; padding: 20px; }
        .sidebar a { display: block; color: white; padding: 12px; text-decoration: none; border-radius: 8px; margin-bottom: 5px; }
        .sidebar a.active { background: rgba(255,255,255,0.2); }
        .main-content { margin-left: 250px; padding: 40px; }
        
        /* Image Gallery Styling */
        .card-img-container { height: 200px; overflow: hidden; position: relative; background: #eee; }
        .carousel-item img { height: 200px; object-fit: cover; width: 100%; }
        .produce-card { border: none; border-radius: 15px; background: white; transition: 0.3s; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        
        @media (max-width: 768px) { .sidebar { display: none; } .main-content { margin-left: 0; } }
    </style>
</head>
<body>

<div class="sidebar">
    <h3 class="fw-bold mb-4"> HarvestFi</h3>
    <nav>
        <a href="dashboard.php">Dashboard</a>
        <a href="apply_loan.php">Apply Loan</a>
        <a href="my_produce.php" class="active">My Produce</a>
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between mb-4">
        <h2 class="fw-bold">My Produce Listing</h2>
        <button class="btn btn-success rounded-pill px-4" data-bs-toggle="modal" data-bs-target="#addModal">+ List New Item</button>
    </div>

    <div class="row g-4">
        <?php while($row = $result->fetch_assoc()): 
            $images = json_decode($row['image'], true) ?: []; // Decode JSON back to array
            $carouselId = "carousel" . $row['id'];
        ?>
        <div class="col-md-4">
            <div class="card produce-card h-100">
                <div id="<?php echo $carouselId; ?>" class="carousel slide card-img-container">
                    <div class="carousel-inner">
                        <?php if(!empty($images)): ?>
                            <?php foreach($images as $index => $img): ?>
                                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                                    <img src="<?php echo $img; ?>" class="d-block w-100">
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="carousel-item active"><img src="default.jpg"></div>
                        <?php endif; ?>
                    </div>
                    <?php if(count($images) > 1): ?>
                        <button class="carousel-control-prev" type="button" data-bs-target="#<?php echo $carouselId; ?>" data-bs-slide="prev"><span class="carousel-control-prev-icon"></span></button>
                        <button class="carousel-control-next" type="button" data-bs-target="#<?php echo $carouselId; ?>" data-bs-slide="next"><span class="carousel-control-next-icon"></span></button>
                    <?php endif; ?>
                </div>

                <div class="p-3">
                    <div class="d-flex justify-content-between">
                        <h5 class="fw-bold"><?php echo $row['name']; ?></h5>
                        <span class="text-success fw-bold">₦<?php echo number_format($row['price'], 2); ?></span>
                    </div>
                    <p class="text-muted small mb-2"><?php echo $row['description']; ?></p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <small class="text-muted">Stock: <b><?php echo $row['quantity']; ?></b></small>
                        <a href="my_produce.php?delete=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this listing?')">Remove</a>
                    </div>
                </div>
            </div>
        </div>
        <?php endwhile; ?>
    </div>
</div>

<div class="modal fade" id="addModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded-4 border-0">
            <div class="modal-header border-0 p-4 pb-0">
                <h5 class="fw-bold">New Produce Listing</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="my_produce.php" method="POST" enctype="multipart/form-data" class="p-4">
                <input type="text" name="name" class="form-control mb-3 bg-light border-0" placeholder="Produce Name (e.g. Fresh Tomatoes)" required>
                <textarea name="description" class="form-control mb-3 bg-light border-0" placeholder="Short description..."></textarea>
                <div class="row">
                    <div class="col"><input type="number" name="price" class="form-control mb-3 bg-light border-0" placeholder="Price (₦)" required></div>
                    <div class="col"><input type="text" name="quantity" class="form-control mb-3 bg-light border-0" placeholder="Qty (e.g. 10 Baskets)" required></div>
                </div>
                <div class="mb-4">
                    <label class="form-label text-muted small">Upload Images (Select multiple)</label>
                    <input type="file" name="images[]" class="form-control border-0 bg-light" multiple required>
                </div>
                <button type="submit" name="add_produce" class="btn btn-success w-100 py-3 rounded-pill fw-bold">Publish Listing</button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>