<?php
include "db.php";

$buyer_id = 1; // Replace with session ID after login

// --- 1. SEARCH & FILTER LOGIC ---
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$where_clause = "WHERE status = 'available'";
if ($search) {
    $where_clause .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
}

// Fetch available produce
$produce_res = $conn->query("SELECT * FROM produce $where_clause ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buyer Dashboard | HarvestFi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --buyer-blue: #2c3e50; --harvest-green: #2d9447; }
        body { background: #f4f7f6; font-family: 'Segoe UI', sans-serif; }
        
        /* Sidebar */
        .sidebar { height: 100vh; width: 260px; position: fixed; background: var(--buyer-blue); color: white; padding: 20px; z-index: 1000; transition: 0.3s; }
        .sidebar a { display: block; color: rgba(255,255,255,0.7); padding: 12px; text-decoration: none; border-radius: 10px; margin-bottom: 5px; transition: 0.3s; }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.1); color: white; }
        
        .main-content { margin-left: 260px; padding: 40px; transition: 0.3s; }
        
        /* Search Bar */
        .search-box { background: white; border: none; border-radius: 50px; padding: 12px 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        
        /* Produce Cards */
        .produce-card { border: none; border-radius: 20px; background: white; overflow: hidden; transition: 0.3s; height: 100%; box-shadow: 0 5px 15px rgba(0,0,0,0.04); }
        .produce-card:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(0,0,0,0.1); }
        .card-img-top { height: 180px; object-fit: cover; }
        
        .btn-buy { background: var(--harvest-green); color: white; border-radius: 50px; font-weight: 600; padding: 8px 20px; border: none; }
        .btn-buy:hover { background: #237a3a; color: white; }

        @media (max-width: 991px) {
            .sidebar { left: -260px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="sidebar" id="sidebar">
    <h3 class="fw-bold mb-4 text-success">HarvestFi</h3>
    <nav>
        <a href="#" class="active">🛒 Marketplace</a>
        <a href="#">My Orders</a>
        <!--<a href="#">❤️ Favorites</a>-->
        <!--<a href="#">⚙️ Settings</a>-->
    </nav>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-5">
        <div>
            <h2 class="fw-bold mb-1 text-dark">Fresh from the Farm </h2>
            <p class="text-muted">Directly connecting you with local farmers.</p>
        </div>
        <button class="btn btn-dark d-lg-none" onclick="toggleSidebar()">☰</button>
    </div>

    <div class="row mb-5">
        <div class="col-lg-8">
            <form action="" method="GET">
                <div class="input-group">
                    <input type="text" name="search" class="form-control search-box" placeholder="Search for Maize, Poultry, Tomatoes..." value="<?php echo htmlspecialchars($search); ?>">
                    <button class="btn btn-success rounded-pill ms-2 px-4" type="submit">Search</button>
                </div>
            </form>
        </div>
    </div>

    <h4 class="fw-bold mb-4">Available Produce</h4>
    <div class="row g-4">
        <?php if ($produce_res->num_rows > 0): ?>
            <?php while($row = $produce_res->fetch_assoc()): 
                $images = json_decode($row['image'], true) ?: ['default.jpg'];
                $clean_price = (float)$row['price'];
            ?>
            <div class="col-md-6 col-lg-4 col-xl-3">
                <div class="produce-card">
                    <img src="<?php echo $images[0]; ?>" class="card-img-top" alt="Produce">
                    <div class="p-4">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <h5 class="fw-bold mb-0 text-dark"><?php echo $row['name']; ?></h5>
                            <span class="badge bg-light text-success">In Stock</span>
                        </div>
                        <p class="text-muted small mb-3 text-truncate"><?php echo $row['description']; ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <small class="text-muted d-block">Price</small>
                                <span class="h5 fw-bold text-success mb-0">₦<?php echo number_format($clean_price, 2); ?></span>
                            </div>
                            <button class="btn btn-buy" 
                                    onclick="viewDetails(<?php echo $row['id']; ?>, '<?php echo addslashes($row['name']); ?>', <?php echo $clean_price; ?>)">
                                View
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <p class="text-muted">No produce found matching your search.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="modal fade" id="detailModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 rounded-4 shadow-lg">
            <div class="modal-body p-5 text-center">
                <div class="mb-4">
                    <h2 class="text-success">🛒</h2>
                    <h4 class="fw-bold" id="modalName">Product Name</h4>
                    <p class="text-muted">Confirm your order below</p>
                </div>
                
                <hr>
                
                <div class="d-flex justify-content-between mb-4 mt-4">
                    <span class="text-muted">Total Amount:</span>
                    <span class="fw-bold h4 text-dark" id="modalPrice">₦0.00</span>
                </div>

                <form action="process_payment.php" method="POST">
                    <input type="hidden" name="produce_id" id="formProduceId">
                    <input type="hidden" name="amount" id="formAmount">
                    
                    <div class="d-grid gap-2">
                        <button type="submit" class="btn btn-success py-3 rounded-pill fw-bold shadow-sm">
                            Pay with Interswitch
                        </button>
                        <button type="button" class="btn btn-light py-3 rounded-pill" data-bs-dismiss="modal">
                            Cancel
                        </button>
                    </div>
                </form>

                <p class="mt-4 small text-muted">
                    <img src="https://www.interswitchgroup.com/assets/images/logo.png" height="15" alt="Interswitch" class="me-1"> 
                    Secure Payment Gateway
                </p>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('active');
    }

    // Function to populate modal and show it
    function viewDetails(id, name, price) {
        document.getElementById('modalName').innerText = name;
        document.getElementById('modalPrice').innerText = "₦" + price.toLocaleString(undefined, {minimumFractionDigits: 2});
        
        // Populate hidden form fields
        document.getElementById('formProduceId').value = id;
        document.getElementById('formAmount').value = price;

        var myModal = new bootstrap.Modal(document.getElementById('detailModal'));
        myModal.show();
    }
</script>

</body>
</html>