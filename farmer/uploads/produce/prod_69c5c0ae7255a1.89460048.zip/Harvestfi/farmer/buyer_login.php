<?php
session_start();
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_or_phone = htmlspecialchars(trim($_POST['email']));
    $password = htmlspecialchars(trim($_POST['password']));

    // Fetch buyer by email or phone
    $sql = "SELECT * FROM buyers WHERE email = ? OR phone = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email_or_phone, $email_or_phone);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $buyer = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $buyer['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $buyer['id'];
            $_SESSION['user_type'] = 'buyer';
            $_SESSION['user_name'] = $buyer['full_name'];

            // Remember me (optional, cookie valid 7 days)
            if (isset($_POST['remember'])) {
                setcookie("buyer_login", $buyer['id'], time() + (7 * 24 * 60 * 60), "/");
            }

            header("Location: buyer_dashboard.php");
            exit();
        } else {
            echo "Incorrect password.";
        }
    } else {
        echo "Buyer not found.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Invalid request method.";
}
?>