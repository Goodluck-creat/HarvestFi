<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Farmer Dashboard - HarvestFi</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>

<style>
body { background: #f4f6f9; }

/* Sidebar */
.sidebar {
    height: 100vh;
    background: rgb(52,173,84);
    color: #fff;
    padding: 20px;
    position: fixed;
    width: 240px;
}
.sidebar a {
    display: block;
    color: #fff;
    padding: 10px;
    margin: 10px 0;
    text-decoration: none;
    border-radius: 8px;
}
.sidebar a:hover { background: rgba(255,255,255,0.2); }

/* Main */
.main {
    margin-left: 260px;
    padding: 20px;
}

/* Cards */
.card {
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    border: none;
}

.bg-green { background: rgb(52,173,84); color:#fff; }
.bg-orange { background: rgb(255,153,51); color:#fff; }

@media(max-width:768px){
    .sidebar { position: relative; width: 100%; height:auto; }
    .main { margin-left: 0; }
}
</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>HarvestFi</h3>
    <a href="#">Dashboard</a>
    <a href="apply_loan.php">Apply Loan</a>
    <a href="#">My Produce</a>
    <a href="#">Sales</a>
</div>

<!-- Main -->
<div class="main">

<h2 class="mb-4">Welcome Farmer 👋</h2>

<!-- Cards -->
<div class="row g-4 mb-4">
    <div class="col-md-4">
        <div class="card bg-green p-3">
            <h5>Total Loan</h5>
            <h2 id="totalLoan">₦0</h2>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card bg-orange p-3">
            <h5>Produce</h5>
            <h2 id="produceCount">0</h2>
        </div>
    </div>
</div>

<!-- Loan -->
<div class="card p-4 mb-4">
    <h5>Apply for Loan</h5>
    <form id="loanForm">
        <input type="number" id="loanAmount" class="form-control mb-2" placeholder="Amount">
        <button class="btn btn-success w-100">Apply</button>
    </form>
    <div id="loanMsg" class="alert alert-success mt-2 d-none">Loan Approved</div>
</div>

<!-- Add Produce -->
<div class="card p-4 mb-4">
    <h5>Add Produce</h5>
    <form id="produceForm">
        <input type="text" id="pname" class="form-control mb-2" placeholder="Name">
        <input type="number" id="pprice" class="form-control mb-2" placeholder="Price">
        <button class="btn btn-success w-100">Add Produce</button>
    </form>
</div>

<!-- Produce List -->
<div class="row" id="produceList"></div>

<!-- REAL PAYMENT -->
<div class="card p-4 mt-4">
    <h5>Test Payment (Interswitch)</h5>
    <p>Simulate buyer paying for your produce</p>

    <button onclick="payWithInterswitch()" class="btn btn-primary">
        Pay ₦2000
    </button>
</div>

</div>

<!-- INTERSWITCH SCRIPT -->
<script src="https://sandbox.interswitchng.com/collections/api/v1/interswitch-inline.js"></script>

<script>

// Loan Simulation
document.getElementById("loanForm").addEventListener("submit", function(e){
    e.preventDefault();
    let amt = document.getElementById("loanAmount").value;

    document.getElementById("totalLoan").innerText = "₦" + amt;
    document.getElementById("loanMsg").classList.remove("d-none");
});

// Produce Simulation
let count = 0;
document.getElementById("produceForm").addEventListener("submit", function(e){
    e.preventDefault();

    let name = document.getElementById("pname").value;
    let price = document.getElementById("pprice").value;

    count++;
    document.getElementById("produceCount").innerText = count;

    document.getElementById("produceList").innerHTML += `
    <div class="col-md-4 mb-3">
        <div class="card p-3 text-center">
            <img src="https://images.unsplash.com/photo-1567306226416-28f0efdc88ce" class="img-fluid mb-2">
            <h6>${name}</h6>
            <p>₦${price}</p>
            <span class="badge bg-success">Available</span>
        </div>
    </div>
    `;
});

// REAL INTERSWITCH PAYMENT
function payWithInterswitch(){
    window.webpayCheckout({
        merchant_code: "MX12345", // replace with your real merchant code
        pay_item_id: "Default_Payable_MX12345",
        txn_ref: "TXN_" + Math.floor(Math.random() * 1000000000),
        amount: 200000, // 2000 NGN (in kobo)
        currency: 566,
        site_redirect_url: "http://localhost/harvestfi/payment_success.php",
        onComplete: function(response){
            alert("Payment Successful!");
            console.log(response);
        },
        onClose: function(){
            alert("Transaction cancelled");
        }
    });
}

</script>

</body>
</html>