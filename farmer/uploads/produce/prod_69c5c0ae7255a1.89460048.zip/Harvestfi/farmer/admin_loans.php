<?php
include "db.php";

// --- 1. HANDLE APPROVAL/REJECTION LOGIC ---
if (isset($_GET['action']) && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $action = $_GET['action']; // 'approved' or 'rejected'
    
    if ($action == 'approved' || $action == 'rejected') {
        // Prepare the update
        $stmt = $conn->prepare("UPDATE loans SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $action, $id);
        
        if ($stmt->execute()) {
            header("Location: admin_loans.php?status=success");
        } else {
            header("Location: admin_loans.php?status=error");
        }
        exit();
    }
}

// --- 2. FETCH DATA ---
// JOIN loans with farmers to get the name and phone number
$pendingSql = "SELECT loans.*, farmers.full_name, farmers.phone 
               FROM loans 
               JOIN farmers ON loans.farmer_id = farmers.id 
               WHERE loans.status = 'pending' 
               ORDER BY loans.created_at DESC";
$pendingRes = $conn->query($pendingSql);

$historySql = "SELECT loans.*, farmers.full_name 
               FROM loans 
               JOIN farmers ON loans.farmer_id = farmers.id 
               WHERE loans.status != 'pending' 
               ORDER BY loans.created_at DESC LIMIT 15";
$historyRes = $conn->query($historySql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HarvestFi Admin | Loan Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --admin-green: #1a5928; }
        body { background: #f0f2f5; font-family: 'Segoe UI', sans-serif; }
        
        /* Sidebar */
        .sidebar { height: 100vh; width: 260px; position: fixed; background: #2c3e50; color: white; padding: 20px; }
        .main-content { margin-left: 260px; padding: 40px; }
        
        /* Components */
        .card { border: none; border-radius: 15px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; }
        .table thead { background: #f8f9fa; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 1px; }
        .status-pill { padding: 6px 12px; border-radius: 50px; font-size: 0.8rem; font-weight: 600; }
        .bg-pending { background: #fff3cd; color: #856404; }
        .bg-approved { background: #d1e7dd; color: #0f5132; }
        .bg-rejected { background: #f8d7da; color: #842029; }

        @media (max-width: 992px) {
            .sidebar { display: none; }
            .main-content { margin-left: 0; }
        }
    </style>
</head>
<body>

<div class="sidebar">
    <h4 class="fw-bold text-success mb-4"> HarvestFi Admin</h4>
    <hr class="opacity-25">
    <div class="nav flex-column mt-4">
        <a href="#" class="nav-link text-white py-3">Dashboard Overview</a>
        <a href="#" class="nav-link text-white bg-success rounded py-3 mb-2">Loan Requests</a>
        <a href="#" class="nav-link text-white py-3">Verified Farmers</a>
        <a href="#" class="nav-link text-white py-3">Settings</a>
    </div>
</div>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold">Loan Approvals</h2>
        <?php if(isset($_GET['status']) && $_GET['status'] == 'success'): ?>
            <div class="alert alert-success py-2 px-4 mb-0 rounded-pill">Update successful!</div>
        <?php endif; ?>
    </div>

    <div class="card mb-5">
        <div class="card-header bg-white py-3 border-0">
            <h5 class="mb-0 fw-bold">Incoming Requests</h5>
        </div>
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead>
                    <tr>
                        <th class="ps-4">Farmer Details</th>
                        <th>Amount</th>
                        <th>Date Requested</th>
                        <th>Status</th>
                        <th class="text-center">Quick Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($pendingRes && $pendingRes->num_rows > 0): ?>
                        <?php while($row = $pendingRes->fetch_assoc()): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?php echo $row['full_name']; ?></div>
                                <small class="text-muted"><?php echo $row['phone']; ?></small>
                            </td>
                            <td><span class="fw-bold text-success">₦<?php echo number_format($row['amount'], 2); ?></span></td>
                            <td><?php echo date('M d, g:ia', strtotime($row['created_at'])); ?></td>
                            <td><span class="status-pill bg-pending border">Pending</span></td>
                            <td class="text-center">
                                <a href="admin_loans.php?action=approved&id=<?php echo $row['id']; ?>" class="btn btn-success btn-sm px-3 rounded-pill">Approve</a>
                                <a href="admin_loans.php?action=rejected&id=<?php echo $row['id']; ?>" class="btn btn-outline-danger btn-sm px-3 rounded-pill ms-2" onclick="return confirm('Reject this loan?')">Reject</a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="5" class="text-center py-5 text-muted">No pending loan requests found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header bg-white py-3 border-0">
            <h5 class="mb-0 fw-bold text-muted">Recent Decisions</h5>
        </div>
        <div class="table-responsive">
            <table class="table align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th class="ps-4">Farmer</th>
                        <th>Amount</th>
                        <th>Final Status</th>
                        <th>Processed Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $historyRes->fetch_assoc()): ?>
                    <tr class="opacity-75">
                        <td class="ps-4"><?php echo $row['full_name']; ?></td>
                        <td>₦<?php echo number_format($row['amount'], 2); ?></td>
                        <td>
                            <span class="status-pill bg-<?php echo $row['status']; ?>">
                                <?php echo ucfirst($row['status']); ?>
                            </span>
                        </td>
                        <td><?php echo date('M d, Y', strtotime($row['created_at'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>