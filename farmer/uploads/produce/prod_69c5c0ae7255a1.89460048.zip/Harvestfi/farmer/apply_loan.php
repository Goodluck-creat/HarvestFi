<?php
include "db.php";

// --- 1. HANDLE AJAX POST REQUEST (Logic Only) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['amount'])) {
    $amount = (float)$_POST['amount'];
    $farmer_id = 1;

    // Save as Pending
    $sql = "INSERT INTO loans (farmer_id, amount, status) VALUES ('$farmer_id', '$amount', 'pending')";
    $conn->query($sql);

    // Get Total Approved
    $resApproved = $conn->query("SELECT SUM(amount) as total FROM loans WHERE farmer_id = 1 AND status = 'approved'");
    $rowApproved = $resApproved->fetch_assoc();

    // Get Total Pending
    $resPending = $conn->query("SELECT SUM(amount) as total FROM loans WHERE farmer_id = 1 AND status = 'pending'");
    $rowPending = $resPending->fetch_assoc();

    // Return JSON and STOP the script so no HTML is sent to the AJAX caller
    echo json_encode([
        "status" => "success",
        "totalApproved" => (float)($rowApproved['total'] ?? 0),
        "totalPending" => (float)($rowPending['total'] ?? 0)
    ]);
    exit(); 
}

// --- 2. INITIAL PAGE LOAD DATA ---
$resApproved = $conn->query("SELECT SUM(amount) as total FROM loans WHERE farmer_id = 1 AND status = 'approved'");
$totalApproved = $resApproved->fetch_assoc()['total'] ?? 0;

$resPending = $conn->query("SELECT SUM(amount) as total FROM loans WHERE farmer_id = 1 AND status = 'pending'");
$totalPending = $resPending->fetch_assoc()['total'] ?? 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HarvestFi | Loan Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        :root { --primary-green: rgb(52,173,84); }
        body { background: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }

        /* Preloader */
        #preloader {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: #fff; z-index: 9999; display: flex; justify-content: center; align-items: center;
        }

        /* Sidebar Styling */
        .sidebar {
            height: 100vh; background: var(--primary-green); color: #fff;
            padding: 20px; position: fixed; width: 260px; transition: all 0.3s; z-index: 1000;
        }
        .sidebar-header { font-size: 1.5rem; font-weight: bold; padding-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1); }
        .sidebar a {
            display: block; color: rgba(255,255,255,0.8); padding: 12px 15px; 
            text-decoration: none; border-radius: 10px; margin: 8px 0; transition: 0.2s;
        }
        .sidebar a:hover, .sidebar a.active { background: rgba(255,255,255,0.2); color: #fff; }

        /* Main Content */
        .main-content { margin-left: 260px; padding: 30px; transition: all 0.3s; }

        /* Responsive Sidebar Logic */
        @media (max-width: 991px) {
            .sidebar { left: -260px; }
            .sidebar.show { left: 0; }
            .main-content { margin-left: 0; }
            .overlay { 
                display: none; position: fixed; top: 0; left: 0; width: 100%; 
                height: 100%; background: rgba(0,0,0,0.5); z-index: 999; 
            }
            .overlay.show { display: block; }
        }

        /* Cards */
        .card { border: none; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); }
        .bg-green-grad { background: linear-gradient(135deg, #34ad54, #2d9447); color: white; }
        .loader-spinner { width: 3rem; height: 3rem; color: var(--primary-green); }
    </style>
</head>
<body>

<div id="preloader">
    <div class="spinner-border loader-spinner" role="status"></div>
</div>

<div class="overlay" id="overlay"></div>

<div class="sidebar" id="sidebar">
    <div class="sidebar-header"> HarvestFi</div>
    <div class="mt-4">
        <a href="#">Dashboard</a>
        <a href="#" class="active">Apply Loan</a>
        <a href="my_produce.php">My Produce</a>
        <a href="#">Sales</a>
    </div>
</div>

<div class="main-content">
    <button class="btn btn-success d-lg-none mb-4" id="toggleBtn">☰ Menu</button>

    <h2 class="fw-bold mb-4">Loan Management </h2>

    <div class="row g-4 mb-5">
        <div class="col-md-6 col-xl-4">
            <div class="card bg-green-grad p-4">
                <p class="mb-1 opacity-75">Approved Balance</p>
                <h2 class="fw-bold" id="approvedDisplay">₦<?php echo number_format($totalApproved, 2); ?></h2>
            </div>
        </div>
        <div class="col-md-6 col-xl-4">
            <div class="card bg-white p-4">
                <p class="mb-1 text-muted">Total Pending</p>
                <h2 class="fw-bold text-warning" id="pendingDisplay">₦<?php echo number_format($totalPending, 2); ?></h2>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card p-4">
                <h5 class="fw-bold mb-4">New Loan Request</h5>
                <form id="loanForm">
                    <div class="mb-4">
                        <label class="form-label text-muted">Amount Required (₦)</label>
                        <input type="number" id="amount" class="form-control form-control-lg border-0 bg-light" placeholder="0.00" required>
                    </div>
                    <button type="submit" id="submitBtn" class="btn btn-success btn-lg w-100 py-3 rounded-pill fw-bold">
                        Apply Now
                    </button>
                </form>

                <div id="msg" class="alert alert-success mt-4 d-none">
                    <strong>Request Sent!</strong> Your loan application has been submitted for review.
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
    // 1. Preloader
    $(window).on('load', function() {
        $('#preloader').fadeOut('slow');
    });

    // 2. Responsive Sidebar Toggle
    $("#toggleBtn, #overlay").click(function() {
        $("#sidebar").toggleClass("show");
        $("#overlay").toggleClass("show");
    });

    // 3. AJAX Loan Submission
    $("#loanForm").submit(function(e){
        e.preventDefault();
        
        const btn = $("#submitBtn");
        const amount = $("#amount").val();

        // UI Feedback
        btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm"></span> Processing...');

        $.ajax({
            url: "apply_loan.php",
            type: "POST",
            data: { amount: amount },
            dataType: "json", // Ensures jQuery parses the response correctly
            success: function(data) {
                if(data.status === "success") {
                    // Update counters in real-time
                    $("#approvedDisplay").text("₦" + data.totalApproved.toLocaleString());
                    $("#pendingDisplay").text("₦" + data.totalPending.toLocaleString());
                    
                    // Show success message
                    $("#msg").removeClass("d-none").hide().fadeIn();
                    $("#amount").val('');
                    
                    // Optional: auto-hide message after 5 seconds
                    setTimeout(() => { $("#msg").fadeOut(); }, 5000);
                }
            },
            error: function() {
                alert("Something went wrong. Please check your connection.");
            },
            complete: function() {
                btn.prop('disabled', false).text("Apply Now");
            }
        });
    });
</script>

</body>
</html>