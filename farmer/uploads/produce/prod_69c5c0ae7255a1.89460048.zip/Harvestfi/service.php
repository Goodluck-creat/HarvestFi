<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>FarmFresh - Organic Farm Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@500;700&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
     <?php include "header.php";?>
    <!-- Navbar End -->


    <!-- Hero Start -->
    <div class="container-fluid bg-primary py-5 bg-hero mb-5">
        <div class="container py-5">
            <div class="row justify-content-start">
                <div class="col-lg-8 text-center text-lg-start">
                    <h1 class="display-1 text-white mb-md-4">Our Services</h1>
                    <a href="" class="btn btn-primary py-md-3 px-md-5 me-3">Home</a>
                    <a href="" class="btn btn-secondary py-md-3 px-md-5">Services</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Hero End -->


    <!-- Services Start -->
   <div class="container-fluid py-5">
    <div class="container">
        <div class="row g-5">

            <!-- HEADER -->
            <div class="col-lg-4 col-md-6">
                <div class="mb-3">
                    <h6 class="text-primary text-uppercase">Services</h6>
                    <h1 class="display-5">HarvestFi Services</h1>
                </div>
                <p class="mb-4">
                    HarvestFi connects farmers with funding, verified buyers, and automated repayment systems, making agricultural financing seamless and transparent.
                </p>
                <a href="#" class="btn btn-primary py-md-3 px-md-5">Get Started</a>
            </div>

            <!-- SERVICE 1 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-item bg-light text-center p-5">
                    <i class="fa fa-coins display-1 text-primary mb-3"></i>
                    <h4>Farm Input Loans</h4>
                    <p class="mb-0">
                        Flexible funding for seeds, fertilizers, and farm equipment, repaid automatically after sales.
                    </p>
                </div>
            </div>

            <!-- SERVICE 2 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-item bg-light text-center p-5">
                    <i class="fa fa-store display-1 text-primary mb-3"></i>
                    <h4>Produce Marketplace</h4>
                    <p class="mb-0">
                        Farmers sell their produce directly to verified buyers through our secure platform.
                    </p>
                </div>
            </div>

            <!-- SERVICE 3 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-item bg-light text-center p-5">
                    <i class="fa fa-exchange-alt display-1 text-primary mb-3"></i>
                    <h4>Automated Repayment</h4>
                    <p class="mb-0">
                        Loans are automatically deducted from buyer payments, ensuring hassle-free repayments.
                    </p>
                </div>
            </div>

            <!-- SERVICE 4 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-item bg-light text-center p-5">
                    <i class="fa fa-shield-alt display-1 text-primary mb-3"></i>
                    <h4>Secure Payments</h4>
                    <p class="mb-0">
                        Interswitch-powered payments guarantee safe and transparent transactions for buyers and farmers.
                    </p>
                </div>
            </div>

            <!-- SERVICE 5 -->
            <div class="col-lg-4 col-md-6">
                <div class="service-item bg-light text-center p-5">
                    <i class="fa fa-chart-line display-1 text-primary mb-3"></i>
                    <h4>Farmer Credit Scoring</h4>
                    <p class="mb-0">
                        Build a digital financial identity to access better funding opportunities based on repayment history.
                    </p>
                </div>
            </div>

        </div>
    </div>
</div>
    <!-- Services End -->


    <!-- Testimonial Start -->
    <!--<div class="container-fluid bg-testimonial py-5 mt-5" style="margin-bottom: 135px;">-->
    <!--    <div class="container py-5">-->
    <!--        <div class="row justify-content-center">-->
    <!--            <div class="col-lg-7">-->
    <!--                <div class="owl-carousel testimonial-carousel p-5">-->
    <!--                    <div class="testimonial-item text-center text-white">-->
    <!--                        <img class="img-fluid mx-auto p-2 border border-5 border-secondary rounded-circle mb-4" src="img/testimonial-2.jpg" alt="">-->
    <!--                        <p class="fs-5">Dolores sed duo clita justo dolor et stet lorem kasd dolore lorem ipsum. At lorem lorem magna ut et, nonumy labore diam erat. Erat dolor rebum sit ipsum.</p>-->
    <!--                        <hr class="mx-auto w-25">-->
    <!--                        <h4 class="text-white mb-0">Client Name</h4>-->
    <!--                    </div>-->
    <!--                    <div class="testimonial-item text-center text-white">-->
    <!--                        <img class="img-fluid mx-auto p-2 border border-5 border-secondary rounded-circle mb-4" src="img/testimonial-2.jpg" alt="">-->
    <!--                        <p class="fs-5">Dolores sed duo clita justo dolor et stet lorem kasd dolore lorem ipsum. At lorem lorem magna ut et, nonumy labore diam erat. Erat dolor rebum sit ipsum.</p>-->
    <!--                        <hr class="mx-auto w-25">-->
    <!--                        <h4 class="text-white mb-0">Client Name</h4>-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</div>-->
    <!-- Testimonial End -->
    

    <!-- Footer Start -->
     <?php include "footer.php";?>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-secondary py-3 fs-4 back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>